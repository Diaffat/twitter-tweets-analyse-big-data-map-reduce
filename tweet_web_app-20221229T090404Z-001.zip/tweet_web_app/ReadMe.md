# pour executer le code:
   streamlit run main.py
# le fichier df.csv est necessaire car il est consederé comme une base de donnée local qui permet de manipule le cache de l'application à chaque update.ca ve dire une fois les données récuperer dans twitter elles sont stocké dans ce dataframe. et si on relance une nouvelle recquette le dataframe change et reprend les nouvelle données.donc elle est temporaire et varaible

# le fichier topic.csv est pareil(considerer le comme le dfichier df.csv )
# donc il ne faut pas les supprimer
